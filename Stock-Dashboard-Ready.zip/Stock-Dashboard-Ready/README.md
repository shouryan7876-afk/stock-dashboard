# Stock Dashboard with Candlestick Analysis

## Requirements
- Node.js LTS and npm
- Internet connection

## Run on Windows
1. Extract this ZIP.
2. Open the `Stock-Dashboard-Ready` folder in VS Code.
3. Open Terminal > New Terminal.
4. Run `npm install` once.
5. Run `npm start`.
6. Open http://localhost:3000 in your browser.
7. Search a ticker such as AAPL or MSFT.

The server retrieves historical data from Yahoo Finance. The chart library is loaded from a CDN, so internet access is required.
